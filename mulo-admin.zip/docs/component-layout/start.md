
安装
```

cnpm i mcl -S

```