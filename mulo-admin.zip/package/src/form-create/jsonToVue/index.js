

export default class jsonToVue {

    constructor(config) {
        this.config = config;
        this.component = component(this);
    }

    

}