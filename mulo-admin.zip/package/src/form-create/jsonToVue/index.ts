import Vue from 'vue'


export default class jsonToVue {

    private num;

    constructor(num: Number) {
        this.num = 1;
    }
    
}