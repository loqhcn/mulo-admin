export namespace FormCreate {


    export interface Install {
        (Vue: Vue): void
    }




}