<template>
    <button class="btn"><slot></slot></button>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>