<template>
    <input type="text">
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>