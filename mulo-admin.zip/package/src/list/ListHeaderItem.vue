<template>
    <div>

    </div>
</template>

<script>
    export default {
        props: {
            // 列表
            list: {
                type: Number,
                default: ""
            },
        },
    }
</script>

<style lang="scss" scoped>

</style>