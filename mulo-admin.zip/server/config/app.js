module.exports = {
    baseURL: 'http://admin-tp6.lqh.cn/cl/'
}