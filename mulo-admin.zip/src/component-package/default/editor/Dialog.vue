<template>
  <div>
    <input v-model="title" type="text" />
  </div>
</template>

<script>
export default {
  data() {
    return {
      title: "标题",
    };
  },
};
</script>

<style lang="scss" scoped>
</style>