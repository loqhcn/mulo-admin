export default {
    //配置 
    config: require('./config.js').default
}