<template>
    <div>
        <button>按钮</button>
        <div>1</div>
        <slot></slot>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>