<template>
    <div>
        <div>页面管理</div>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>



</style>