<template>
    <div>
        页面数据
    </div>
</template>
<script>
export default {
  name: "cl-render",
  props: {
    propName: {
      type: Number,
      default: 1
    }
  },
  render(h) {

  }
};
</script>

<style lang="scss" scoped>
</style>