<template>
  <div>
    <default-button></default-button>
  </div>
</template>

<script>
export default {



};
</script>

<style lang="scss" scoped>

</style>




