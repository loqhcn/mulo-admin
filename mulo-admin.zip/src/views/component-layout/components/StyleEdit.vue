<template>
    <div>
        样式编辑组件
    </div>
</template>

<script>
    export default {
        props: {
            
            value: {
                type: Object,
                default: ()=>{
                    return ''
                }
            },

        },
    }
</script>

<style lang="scss" scoped>

</style>