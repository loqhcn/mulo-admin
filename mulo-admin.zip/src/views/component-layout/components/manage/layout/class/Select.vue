<template>
    <div>
        单选class
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>