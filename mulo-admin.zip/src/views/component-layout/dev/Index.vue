
<script>
export default {
  components: {},
  data() {
    return {
      name: "罗戚洪",
      viewId: 1,
      title1: "123123",
    };
  },
  mounted() {

  },
  methods: {
    /**
     * 当渲染模板时 替换props
     */
    beforeRenderTemplate() {
      
    },
  },
};
</script>

<style lang="scss" scoped>
// 同步css
button {

}
</style>