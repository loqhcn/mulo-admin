type Vue = {};


export interface VueJsonParentResult{
    arr:VueJson[];
}