<template>
    <div>
        应用管理
    </div>
</template>

<script>
    export default {
        data() {
            return {
                
            }
        },
        created () {
            ;
        },
    }
</script>

<style lang="scss" scoped>

</style>