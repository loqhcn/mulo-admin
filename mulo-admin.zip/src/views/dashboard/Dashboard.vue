<template>
    <div class="panel">
        <o-table>
            
        </o-table>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>