<template>
    <div>
        添加用户
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>