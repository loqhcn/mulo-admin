<template>
    <div>
        用户列表
    </div>
</template>

<script>
    export default {
        

    }
</script>

<style lang="scss" scoped>

</style>