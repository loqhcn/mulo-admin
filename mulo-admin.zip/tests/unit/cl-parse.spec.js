import { expect } from 'chai'
import { shallowMount } from '@vue/test-utils'


describe('组件测试', () => {

  it('test1', () => {
        expect(false).to.be.false
  })

})