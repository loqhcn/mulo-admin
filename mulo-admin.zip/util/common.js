//常用功能
class common{

    
    


}

export default new common();